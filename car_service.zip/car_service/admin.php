<?php include 'config/database.php'; ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
    <title>Caarrr thik kori</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=PT+Serif&family=Staatliches&display=swap" rel="stylesheet">
  </head>
  <body>
  <header>

     <div class="menu">
       <ul>
         <li><a href="#">Home</a></li>
         <li><a href="#">Services</a></li>
         <li><a href="#">Appointment</a></li>

       </ul>
     </div>
     <div class="t1">
       <h2> <b>OUR ADMIN PANEL </b></h2> <br>
       <h3>We are car doctors.</h3>
     </div>

  </header>
  <?php 
        $sql= 'SELECT * FROM appointment_user';
        $result = mysqli_query($conn, $sql);
        $appointment_user=mysqli_fetch_all($result, MYSQLI_ASSOC);
    ?>

  <div class="t1">
  <h2>Appointment Form :</h2>
 <div class="tbl">
 
    <?php if(empty($appointment_user)): ?>
      <p style="color:white">There is no value</p>
  <?php endif; ?>

 <table>
   <colgroup>
    <col span="2" style="background-color: #D6EEEE">
    <col span="3" style="background-color: pink">
  </colgroup>
   <tr>
   <th>Full Name</th>
   <th>Address</th>
   <th>Phone No.</th>
   <th>Car License number</th>
   <th>Car Engine Number</th>
   <th>Appointment date</th>
   <th>mechanic</th>
 </tr>




 <?php foreach($appointment_user as $customer): ?>
                <tr>
                  
                    <td><?php echo $customer['Full Name']; ?></td>
                    <td><?php echo $customer['Phone No.']; ?></td>
                    <td><?php echo $customer['Car License number']; ?></td>
                    <td class="normal"><?php echo $customer["Appointment date"]; ?><button class="work-button cngDate" onclick="change(this.parentElement); status_update('<?php echo $customer['id']?>');">Change</button></td>
                    <td class="normal2"><?php echo $customer['mechanic']; ?> <button class="work-button cngMech" onclick="change2(this.parentElement); status_update2('<?php echo $customer['id']?>');">Change</button></td>
                </tr>
                <?php endforeach; ?>






                <?php 
                $id_chnge= $_COOKIE["IDD"];
                // echo $id_chnge;
                if(isset($_POST['submit'])){
                    $date=$dateErr='';
                    if(empty($_POST['Appointmentdate'])){
                        echo $dateErr='Appointment date is required';
                      }else{
                        // $date = preg_replace("([^0-9/])", "", $_POST['date']);
                          $date = filter_input(INPUT_POST,'Appointmentdate',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                        //   echo $date;
                        //   echo $dateErr;
                      }
                    if(empty($dateErr)){
                        $sql='';
                        $sql="UPDATE appointment_user 
                        SET date = '$date' 
                        WHERE appointment_user.id = '$id_chnge'";
                        echo "<meta http-equiv='refresh' content='0'>";
                    }
                    if(mysqli_query($conn, $sql)){
                        //success
                        // header("Location: admin.php");
                        
                        // echo 'lessgoo';
                      }else{
                        echo 'Error: '. mysqli_error($conn);
                      }
                }

               
               ?>

              <!-- for mechanic -->



               <?php 
                $id_chnge2= $_COOKIE["IDD2"];
                // echo $id_chnge2;
                if(isset($_POST['submit'])){
                    $mechanic=$mechanicErr='';
                    if(empty($_POST['mechanic'])){
                        echo $mechanicErr='mechanic is required';
                      }else{
                        // $date = preg_replace("([^0-9/])", "", $_POST['date']);
                          $mechanic = filter_input(INPUT_POST,'mechanic',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                        //   echo $mechanic;
                        //   echo $mechanicErr;
                      }
                    if(empty($mechanicErr)){
                        $sql='';
                        $sql="UPDATE appointment_user 
                        SET mechanic = '$mechanic' 
                        WHERE appointment_user.id = '$id_chnge2'";
                        echo "<meta http-equiv='refresh' content='0'>";
                    }
                    if(mysqli_query($conn, $sql)){
                        //success
                        // header("Location: admin.php");
                        
                        // echo 'lessgoo';
                      }else{
                        echo 'Error: '. mysqli_error($conn);
                      }
                }

               
               ?>
 </table>
  </div>

  </div>
  <script>
        
        if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
    </script>
  <script src="js/script.js"></script>
</body>
</html>
