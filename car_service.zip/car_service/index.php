<?php include 'config/database.php'; ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
    <title>Caarrr thik kori</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=PT+Serif&family=Staatliches&display=swap" rel="stylesheet">
  </head>
  <body>
  <header>

     <div class="menu">
       <ul>
         <li><a href="#">Home</a></li>
         <li><a href="#">Services</a></li>
         <li><a href="#">Appointment</a></li>

       </ul>
     </div>
     <div class="t1">
       <h2> <b>Caarrr </b></h2> <br>
       <h3>We are car doctors. At your <br>service anytime.
       <br>Your car our peitent.</h3>
     </div>
  </header>
  <section>
    <div class="hsection">
     <h2>Services :</h2>
     <div class="container">
      <div class="card">
        <img class="pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRr3wBHIP8g7KdZ1siywj9qKtdFziALXG3r4g&usqp=CAU" alt="">
          <h3>GENERAL SERVICES</h3>
          <ul class="lu">
            <li> Oil Change</li>
            <li> Filter Change</li>
            <li>Car wash & Polish</li>
          </ul>

      </div>
      <div class="card">
        <img class="pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3JGnDCBwdItW1cZYKh_4Z3ubli3-At3QN9A&usqp=CAU" alt="">
         <h3>TRANSMISSION SERVICES</h3>
         <ul class="lu">
           <li>Transmission Repair & Service</li>
           <li>Transmission Overhauling</li>
           <li>Transmission Replacement</li>
         </ul>

      </div>
      <div class="card">
        <img class="pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjCzJkZ_IWIxlktuMIIzfvUx5pkOsZFIfotA&usqp=CAU" alt="">
           <h3>ENGINE SERVICES</h3>
           <ul class="lu">
             <li>Engine Servicing</li>
             <li>Engine Overhauling</li>
             <li>Engine Replacement</li>
           </ul>

      </div>
    </div>
    <div class="container">
     <div class="card">
       <img class="pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSf4K9vDwZqxXK3WNrWDUoIoxHTdo_6OuTvog&usqp=CAU" alt="">
          <h3>WHEELS & TIRE SERVICES</h3>
          <ul class="lu">
            <li>Tire Installations</li>
            <li>Tire Rotation</li>
            <li>Tire Replacement</li>
          </ul>

     </div>
     <div class="card">
       <img class="pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQItaPTqlEXbsEgsybwRPYPGj4bQXY7FrtAsA&usqp=CAU" alt="">
          <h3>AIR CONDITIONER REPAIR</h3>
          <ul class="lu">
            <li>Heating & Cooling system Diagnostics</li>
            <li>Auto Air Conditioning System Repair & Service</li>
          </ul>

      </div>
     <div class="card">
       <img class="pic" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAAAclBMVEX///8AAABfX1/r6+tjY2MHBwcnJyeDg4NLS0vz8/PT09NbW1s7OzsrKyszMzMfHx/f39/5+fkNDQ21tbUaGhrIyMgVFRWLi4t4eHitra3d3d2Tk5PLy8tERER7e3tSUlJubm6cnJy7u7umpqZHR0cwMDA+IoJEAAAF90lEQVR4nO2c63qiMBCGSRUVTwiesGrFWu//Fhe0OQcCJlXc53v/bZdO8kEyM5kkDQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACApiTLfBqnYXvS+Jh9v7r3jChLiQurbfJqCTeWGycZJYPDq0UU7J1lFIS7V8sIzj50FEpePVMOoR8hZNN7rZCrJx2ETF6q4+JNByEvnfBzj0Je+UkOvBvH3aLXnsWFv4owep2QnPXi62EbH8zG3mPP2pGwiH50MDKjRq7+esaJeg3SBj7V1w5N7f5sui+G0/JVx5OdRcyR9mDm1N6KmsmdzKj0+KAl8aXuyU/23NapRTbTUp/J42FFRPo1tr/YUwunJsfMTu17a2lUzchrvDuT7DDVb1x9GeJEMVGpHDZLby+SJ9CfjpYYmaaDpFXZ3Ik94RrJeizzfDwcyUSmpd7Q1nrfud0RNbVyNnXHmANW+NYte8B9KcFDydLZ1o0+tTfafW/ZCtY8tlhAjt3bTVhbJ3djJdNfc/PyH2wyG8P2mr1EH+OahZLQz/pqJvatVzt02Mfz4mn4a3GLrZSBOL+jOiHcLUy9tkwGXs3JQkwT8Mxe4dlLy0NmzyX/ZDQXQmeTr+XQgglxd+ZBCyE8PfK1QGWZtHN4LWkshGcAvupRPIT5GKtNhXC/7ysUe/YeTYXwSJx5aPUO9+djd2NNhYx8NvrLt8+X01AIdzFz9zYZbAWxqVrMResbn/aFZDMhYz4KZn1/sJhIhhUrTuorw2tmGQlNhJx5g3/H1LjNMBaeONYGTruQsb+qdT1Hw1cZS0/kNSPMKmTnaxfBTqpHKFkImVdnyjYhPovvVvS9H0UIGVQqsQhZP+97lKS3BcLlxDiqT8yrRle9kOQZ01zqZyCmxSbyh4TU2/wLirTLsmVcUS6uFZK4b0O3pVhlWbbwRw2EJPTh33R0pxpJN37nTKjb+xZSMDPmhbYkhH3V+O4cZJODfenoD7m3Xd2vMlh/buXScxYk2SCmrAy/ly1KVPclC2Gp4WxXpjjSVM+ov1hMiQ9GtCvRh/hjOaVX3a9AOrqIHkwWcq7+PaHWkWhO8QHEdWYu/Fxe7tQIKRgIcUcWElXObqmM1nN3AjMpHgjfOGwhRMz/ZSGVx0xCOQ9yP40ip6XCXjFpJYTkFUKCilGj1DUj1wmvFl2F3ft2QtjGsCqkN6t93DAWHkKtAPGtsLZC6FhRhQQ9Yx/VbM7m622oZVIhN20phHxUCAmSoSG0qkJy/ZFWqF9YCL1thfwWwXUhxUfZTtU5oC7fTqq5lqj1fMF7BMF2OqeYBnp+KNmyLl4qhdzEFMFTeB1qmUPfeGzHj2JvIggxbAZKjJWPmNcKuYnhv6x4mTVxRNkUETcAbUkj2wemk/nURoiyjTsiruSSPXG5YBPCShD0K45aCdmIEfHsrEN2H9LpQsvQ4o77MSFkwLPni4/8V6g0HKSMp5j5xylFq+DMeOX+QSEk3d/To55rDKFk93kSDeX3InVBdb8rYWA8KqQYXpPt/uvH39IqHA33w5M6JeqEDMRF1eNCnkONkIm0I/S2QuZKevGeQuK+Vvl9KyHRrmS5NhUY30pIHRACIRACIRACIRAS8Nsb9/U/rSKYzuN1XAgtSW3KnJglZaaTRh0XwkpI8/OSb7KYThV0XIixeGe8/tBxIYGpemc8Vhh9ULQdsPTDDa0DA/ZfzYWcdR2h5eiNVsdyu9ATBFoPWvSfo9fbbQe/OipkoVZuf2znujoqJFjI0+RkPZ/WVSFBlPHq1KrBYdXOCilc6/6nLFTGk0uTe2cdFlKSND4B3XEhzYGQKv5fIV5uLNiZqO26nmbXzoD4O6hei7aJ5Hr1Qsv3/NxPsqKdQHO9Ua9tFnm51WNHO3viel1sqdjbeOlmA5STDu6XepTNwSeNrCIRkPLMjdsl8BL5QPH1eX8TaSz4mdTHgBaPqsfuL6Y5C3aSy3QY/wEOzHNNnvxXRdb5fLW55v78y7I/26ymtoshAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeCv+AVPEWIvSn+yLAAAAAElFTkSuQmCC" alt="">
        <h3>AUTO ELECTRICAL SERVICES</h3>
        <ul class="lu">
          <li>Electrical System Diagnostics & Repair</li>
          <li> Charging System Diagnosis & Repair</li>
          <li> Starter Repair & Replacement</li>
        </ul>

     </div>
     </div>
     <div class="container">
     <div class="card">
       <img class="pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7OPuWX_5SDAFaWHogKVMwG9s09FrXzgKbCg&usqp=CAU" alt="">
        <h3>HYBRID CAR SERVICES</h3>
        <ul class="lu">
          <li> Factory Scheduled Maintenance</li>
          <li>High Voltage Battery Testing & Conditioning</li>
        </ul>

     </div>
    <div class="card">
      <img class="pic" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX///8AAAD7+/sBAQH+/v78/Pz9/f319fXy8vL4+Pg5OTk1NTXm5ubp6enX19fw8PCWlpbDw8NdXV24uLipqang4OB8fHy9vb0YGBijo6OKiop2dnZmZmYmJibOzs4cHBxQUFBISEhAQEB5eXmEhIQODg6IiIhVVVWUlJRtbW0jIyMrKyuenp7JycmwsLBiYmLX0JrHAAAQLElEQVR4nN1daUPyMAxuceMQGOIYpyIivooH/v9/9+5ou67HmnYH032QCWmTp0ma9FiHfJRefq+f3fR6Xvrp9XrZF/2eSOITEgitROJRkpppS8SsAhCZaOsRul+lbe1LOnGpWSsWtF4VgMhEqwAI13ZNGuwBudQj9BVMNCXpZCdTDaAvAGzNB9sy0SJta0K318kIYnbRBz2FBt3F7LIPVgoTQkDskg+qNFghmrUudLVOBsw6p4UCvGqYqJRRNgjw6mEC0bZtSOhquWgNmQyj/TU+2CDA35eqFWj/sg9mtB000Zrb1oJLswCrBfpaALpwuVqqltM2C/BqqRpH247Q1wkTlPZPhYkWAHYpTBDav26iCP15gEhXsrMj+nBoKWaNAFvxwSm+HdUBsBupmor1M8bjoWchphOX+gBaB/ovHF/jgYWYJoAdS9WiGN/NTWKoFmLWo8GW4uBHAvAGpxChrLvgg2CAJwIwNVSomB0IE2CA34mN4uyivmgW89eECYQGT1SDCdDMFyFi1ih0w+PBHw7gDdEiQMxrA4Snahce4A3xRVuAnU3V4mua+yAFOh54ZjErA2xtRH/AvIlmF/HFUtZNCN3InMydDDC+SX3RJOZvCBMIBVRtBYCxoY6aBVgtTFiw9tZqgImhegbWVYRub8rijBUmSnxxaGD9C8JEEigYLgkpyW5K9ADlckWAE52JktA/agZgeyaajHpLAKZBQ8+6utCNT92jrQFgMupHWtYCl2YBOk3do73eB1noH4/KWHd3RJ9+M3zU4CpkqWl20wzAZlO1uKs/m0w0Q8rPwBXF7PiOX7QwAaQ38gwcqa7TYcJPp55AAPNRv1hdl8OE7/tjkIlibgZOEtNa6GqdjN3aBFrCASYzcANFddYAWzTRHgolPZUjjYfEkphGLtcEOIX6oOSLnJiWAFv0wZj2CPdBcpPPwPF6uGqqVsb6n40P0l8SLXrtAnTe0jw3maj6l8IMnA9r8vZTtYR2+mprouTmduAVxOyqD6JnBxMlEIszcJ3sRfvpIgysF9XPwNHBSTcBzqEAlb+kM3CWAFs20cQJXXxQMQNnK3RLm/GOjj6Yh342A9cgwApPvpwgeiolYTNw/U5qcFXFB+kNm4Hr1Ig+q25azQfFGbiupWoIjcbOYaJ4Q3yxvTABbYxdDSZKIGah3yB0y2ECJRMzVRQnz8B1DWAAAwhESiF2JpNBaPaqB+iiyswXOwQwWcsGADSSsFrwc6nQrZsomXlyVZyCFr93KdBz64R1+GCmyVEbqRoY4B7rl3rdVIm/kH7hrd0RfXJNpcV6N8VxtE8DJO1ru1aqhlA2tVajicafG0SvDvggutcCdI74TwCA7Gq6F0XvEIBGkmKwWWgBZiY6/V5sT++roBWA3HaLiorLf0lU2NMA9JG/uKU8nxYe8hsGOIcAtO1oQ6IqhdAeWZikBV43w2YBRlqAFSL+rZexVm1fmD0XS8Z6fJ/AADp1MmgDENpIItKGGoCx5QavqtZ72CN61axBnxppTala9nlLZFBoMNCUxE9fQwcNIhNt/EvPKLR9bzMn8/kSwP7wSVNF8ue895G8CllhRE9IHuykB9CO2RaFgiDI97LIq69zfBcZtWL/gOR3jaladq2QCuAlGE6+dFVgdh1C3v4q+iAheZMGhhXCRHwd6QJUQZCQYTByednTKZBqAJnxBCLrahE/9kLCmufS+5S56OrE+HMb1afBuAPfaqXXyqAXMx3aM9asGb8YHaD1kj/HzYx1VdWfwh5rtKLDVbaESFQoABxieBXs5i30DQDZCBT1PaEximnwxJJ1CS0+KgB6aAeoQiRJrvM8jpK+CDD7YjTo+Z43nc6GaLCPJjMULsL5QDMU/ZbNzTXif3PGQwF6gb6kqfL1bj4SAHrB8f5+gxZPt8fvxDie067kAR3iv/SpM3oxpDR3s/NBBe0t7x3M0++tW++GU+X6ZV8UO3mSbpu69iXBNg6T8d9x+xH/vf/5+Tnvlv824SrtkYlKPZ+MEaukatnNnANIKu+JmaGLI6wP59Ndem2XL4my1q9YugoGnlyHrxn10/3ZlXWR9lkB0PfETYC6Okv66pKr3JPfEyFml6M76+IvK74Dp55OtufU0lfbx+wV+t6ta2N9LEQo1pUdbCSyozU3xvMHxlBaM+uVEILJf8OPuoKRS2OwqwbWYyFlZnDppv86HKEybZXqVsKYgI3x8j3jTSmuur9CaB/FQQ83iF1eRaK6G+4iLdwzgNmsc+sS1dxwnyNxjp4DiAa3AEfopOLyG7pSIQIkip1iG6G7o7j8Zj0QAPqcBpP4P+my9ADWyXphEWCvADC+CYCC1N7129Bqf8G4VwSo2te2/32K46BvRQ32FeuDXOTvUg8CAohVe0ukBdB0ZNc96UG0J9lE2So375p7Ixcj/yv5ayRrkF7FrwNDo3VLcfnNAxRgus26Uz0IkDYAA4wh3rpyqYFWR2KiPSjnpxnAUcjPtaPhW938m2+mb+WcM9NgiO8HhQdKd52SHkDymEe+4qQ6wZ3MRM05gOnsZUd6EBjrUHNuGQEYpnQvI8RN0M5fJXZGWbEFLjtaE8njyJd8MFvlzr7+yKp4DNi0tdcj/U2nFZff3OkOZsu+vrBG2hK6LF1ddkN6CO3UUwMkev3Mp3VvoxwgZ6nX60FgtDsW+VQAhS1XG35OfPpGfzLyv6a/4qBMg6g3LhZ4m+UTVGQOrpuKY7+QBUPVMmb6dyG1SEgLJF45e7Nq8rZ8kFv2uUmWKngNFpcm+/21WDnG5yHicqDFkxFXvV0/hDaKTp+U5FWnwXTbF/XCYhVP39zYEQ1PRlxtK/kSZ2Cj/b8M5Fbtg2Rfm6fZA3WinU3aNEHlhx7r9dcH2lXM5otNONIDjOkWGi74MyjofqXYjHI1VX4O8pVjXS9KnNEbfeq5fPHGjUZfZumNuGry129mX8btPDQYqFvvMEX8OGS2LKGtaHZW1Z1EgPotdch/Km9GuhmclIxoAnDFMJEuEUIBZvG8hAvGP7NCSTQ/6mjrVWUJLT4+LIAmGo8f3rBs7sU61ythe9bitZR/Kx3tAajBRN7VIzZx2fWKx0kN6Cl4bSpOuBnY7BkMNcdNMS54vRe8d/LQpPSQhotKTyJHHMBU6PDW1Fdvi03jof1zUSIjrprCBL0JEVSDJCqGj6wGdesdI270n5YM10ySthTH3ZBlNMDOa9pF9sMPg0S0TjZ29O/kVqlDeghAfAcFyAu9+CyTKA3/fMm+j2a7BqQHVZftFLMEGP96yftVJf9QWm4M7iFOU7MPJjfvQIB9Ae4ojXX61nvoSXs55h9lghiV4arkOwTceY0krWTxXMeFprx5MEJocwMWuj5//YI/oCM9+dLfKPpV+g0ZNhbTiQF/qFNLqgzBe+flnfQeGlBbVVY+DuQFgohmAM0qjiOZICBAzZMvPbblWsXljrott0i3H+PC1VSYoDdDae+87ukH7aM9X2stF3ycFAFmlUffl+Uz4NRfAEAj7b0HBYh0APtokGFUc7kglacnjKLv7T17sL6BMJFd70hgbQ0wLTm6U/AlDfwz1DsCmgVfhwYUx2UfgYa1HcCkIE3MFFzmqFg511cntYzCA84L19vRZg9UwJ5AKgcY/z54V9tq/PEy0ACkCcRkSx+3rTfi0xwZds6reag8VNlq+sXn3pROzIDHH9r66xAMsLjtS+dXw/xke6Glt8gzcJn8YKyX1bGjXToBLMmBfDR6V7PD40iglT19r5u6cu9tZkoxNU8BQh9Snm0xVqarCxMXhNIhS01hIvncWmgQWbyVbKZ5C8Pb1MhlxI71qJzsxDevQ7vnOEUNakv2s35DIRFZbSzjMj0DpDdqMKO9NAQwWyw9YdlW42Hj0MAl/gwOAPVAAL7VD3ARcSUnJxX/pzngie2V8kBEo+JE2ondw+IAgNM4tk/pjFWc0U+XKv4nOYmX+qwjdlZcfnNn+Sy1GWD2KM1uypWcvmB2MYkeAxPAhVTIAemznQazbV/lAKfEPE4TruTkRRQEk2GjHuCAbgaoFPEj6zdyGDuZZW6ImR5RaqsTha0+T8pOTdAfBAX3wbgVrUw0XeU2AJzxeloOOdoJDQCcIBfmrxJA6Xkcl6HVp+/bAswjvqbkrtjS/2b8+owU5PBhWOSSL1T+mKSHIN3ni2DIBJCJWQ5wIoW/bU7bR9FOlOh1pQTYnwhCO+2pObu8NKYcIHqR4vtDkUuU2ypp6V1P+UK+NKupNgOHaUdgceSGZwDIncFFuQSMC7mhM4mMhK42itUF7NhAh1QtuS5wgNypV6UAubMyKBe6yzF3BA9FPwWJYkvuq6sLP4XqrCZnHlwA9soB5ipkrR8paQPeVnG2SVWqzuvRLTkuPpieYwkE6AMBcm8EY+o56xojEM7V2LDDWordXrog5+KD1D2sj4orGy5Jz1tSX1f01bHC7wsSPU9FDRJBIjoHZzd/yB4kkFiXm6jivLZc6LMkyK6US8AO6Ey1FCoBxqqdizvkAQBDsAbFyb8SgJHMdlLOBe0LtnoWX2pDafuL3FQhWWoS6qEA5flpfUnxLJV4FFWmwWyosucP2MB9He2IDjMhPnhD80XrTqYcYCS358QAMOUS5HPd+eYG8THHeJj5ADXR7ObOxQdR6VvJzhLbFwjA+Pom2/voyf2ak3qTLTmAMEG+uHfSYNlbySKZ7RTo6YjsJ2KnwikBomxLjtFEyedEOq4RtK/N1wJMxgICl6WNncQYH0wA46/ezSaafW7d30ylARjJ7TmzG7OsaEDUAkxqmZmeAsxu1sM+GKAQoXRm9yA5wskmGCnioI42UG3KFb/YmF+9Vb6vTQ7efHtmn9O+s52U06I5fVpAGxDpwdx2nUx2oxH6RwJ4QnChLTSYkWxKfZDrsxzaVl2SnbWZc5n0NbRVAaa0g38KU2UA710A8qvcckn5BPhTw++gyxJ3NUAyrHDwQaR7K5l8XCqeuTQjvDGS9G5/qzTRmyxZdGWtLIkOEsB/9kI7vHPg8oTliX+ypu3etnJJj543wNnJrA2AsTu+i217c5Nlty69qA5gPELINkVzdrKFAnQ0UUrik4VGHuArHKCyXl3JkB30l9jJzFboCq/F4MYmKdJVxbbVjxAuYwZw2wpAtoTCnpJLAB6sAYqsNSVjW/UvH4TLsA2AOWs0Wt0t7wnMfSUTLQOYFPAv6aamLQxgNR+Ud5wNJvPF+7ZKJ1MCMM8Zk0eAR61qkLKmh0BUbFtT0/jI32za9EGnA93Lp47cjNvG0500WCNtTUOg9gFCxay547gqQDXrWrhcwQfhL0Fpw07sha6Vtkahu+eDXQBYV5jQsi7+174PNm6iPV1JZCzZTKpWbydDSDrmg2DW4BBciUunw0QJwL+QquUkfzRV42h/Z5iwYd0Ol/pNFJloqwPseKrGSKoLXU2DFd0fIOZ1ADaeqhWr+30+aClm+6lae52MM8COD5eE6n6HD1bRw58NE0xMd6F/hYm2DrC1VC2vrh0uVwoTiER8J6GrvQK4zRD8HxmvS3pgNH5NAAAAAElFTkSuQmCC" alt="">
      <h3>BRAKE SYSTEM SERVICES</h3>
      <ul class="lu">
        <li>Brake System Service</li>
        <li>Brake System Overhauling</li>
        <li>Brake System Schedule maintenance</li>
      </ul>

    </div>
     <div class="card">
       <img class="pic" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX///8FAAEAAAD39/f29vb6+vrh4eH9/P3z8/PT0dHx8fG3tbYWFBUdGxyCgIHr6+sJCAg9OzzZ19hEQkMlJCRbW1skIyM7OTrJycmcnJwWFRWUlJTU1NQfHh/s7Ozi4uJnZ2eIiIgzMTIsKiu/v79tbW1XVFVISEh4dncfGRukpKSwsLAQDw+sqqskHyFxcXFaqTJ+AAASlUlEQVR4nO1diXriug4OXrBJWUKh0EKZsnSblum8/9tdy85GEq9pymEuuvfMRyGJ/FuyZDuSFUVXutKVrnQ+IuSs7HHn7NnkV9csjDSZsG4ZUBJ3zMFIjMS0Yw4Y045ZGAlT3DF7TgkNGgiEYEFtxxBlHAdBJJhjSrD1OsY5pTRESznF4v84rHdy9kQ8I0iFhFjEjXb28HhOeQBCAu0SnS+ULKB9GUn2OIC9ZCvutEEUY1BcIiB6cyB5x7eRohACtMCffdGvFvZEyJpR6m/MCHBgLP3s30JFUn0o/dWKvamDGBGjHCyNt5aIsRvBOCBU8QuSIhP4iHgU91ZzqUDC0Cn2eohChzkjIc1THOSn9O+QsQgtE3bO/1ZlAuQnph6keQYBIQiI3hKkwEHZ33Q0kgBrKGQn7Bz2v1UYj5yx+hc3ImQE/CBr/tHGgmbPFl1JQVv8rSEXvgZcsf+dss1ps0GYmDS6GzCzlIl/Q1xh0YlM4BO2IkTTuGhlmKspy1BayqaHgHJizLi/isrnggcjihmI07+Zot/FncRhSmJhj3XshYkR8APGoGqffCYX98NcIUDRMSOg3YETUtUvYrJHYBBrLKV0FCx0xo3VLIQxySHgIcCehii3Yq8wMWkPWOMY5KIXglU0gm5TPGgYQNAt4SpCjJxii0vsG8dgDPIVsg5fFVLVOu0gMBED5Qb24WumEvsmFWWxWHeIQRS1Wfaq2SAOMTIchCfYt5qwS4hYMwbhV2FlQueS+VOEjofMZYQEYUUTt2NPAVuzH5TdTzltvawXgyHIForxx3AcPAYL9ljbv8LV0jBHX3kOCZmrRUJ6JG61plQkOlg7oRbj/Ht2RsJ6icS4tQRthEPW9N/JvmuAV7rSla50pX+bWPCK7j9NvP/8sHt5O6CUhn/O3aJvpPj+4W6EynQcin8ezt2ub6LBeqZQ9UqEhgCx5dLjP0GP40UVXAoRpHjxQuQf+0Z0OcT9uVvYjp52engZxMm5G9mCnra1sVeDuEKXa04nWzO4FCJ6PXdDA4ntXPBJiOcN8Qmlx5EjQAHx5tyNDaEbZ3wC4d9ztzaAnj0ACjW9vPkptRjQKsL7czfYmz498AHC3bkb7E3vfgiT5bkb7E1bH4RoeET9H2kW54R/DzEPGSK5wPjoHl46v/ou8pDgcYV66K1zgKl1R19eA0g18ZDdg0aJ562wyD/KLul69v2Ud/uXN8B53inICeKpsJP0765n39tCsXwhLnqF2BH6bYMohPb6d31z/zghsBMFIZ0Q0RcWqOFB5YHjBRHNK19YpIi+ti/vf7d3grZ/dx83ty1f3rpSfGIafCDOK+PWqqg1mzR7/+x3P2k7RdhzNzfzpIawZ1HUEjjhJtSfyfZPxw6xgtDVotZUVH3rZlEVwAJ1t3KsIHSEWLiJStNHTggLgPKmbt1FFaETRAGw+SIHi6qmaid/d6ymtbbaIaKqkSn/ZlNUdCpB+GbQLcK7WmuRzaLODVMzu7kZrqpa89wtwtuG5m6MjZybJp9Wi3qsAuwcYfSnPnlOEsPEemH4UV6AjAirTuYHEEaDV3OT/cmEsP5r9wiFQe270O3g1n7Rk98uhoTsZmnYr86nedwpffHDH6Gbt+CTjnePqWMM184foVPPmaLhg1KqGjhQpxC+CkL72EQbF/aU6pdZRPxGcMscYIapDDW100MF4XD69tLb7Gs+orjCaRtDBpM2/0SojNYPy+jJCGJhmdsT4hOBodX0iGY3a7Qf6iC67JgSwmmkBxjJAMo2ECHDUabeuFw82U0LvwEAhaaO++P5UQPRwVlAWpMuBbUUQdwiR5JEkPzGuesyJ+4//3l4v5st0D4BgSJ0eLy9ax6LDoYGMmwZ5o2htFJwJA3XD82RZIQTRnlAchbvr1cIHRMQ45p9NEK0vyTFnDOqSdAECTLO5H9RqBQhaYrLFE3fOyEIm35Ml7MDQJxO+psGm4o+LU8hVHQxpE82csizv9IEwhCEMmctJLNIZfdFdHyYfck9i2f2Vl+r2WJqZCI34Zq8NQCUpu6x/As/YjimRKhJQOINVrkaUXS/3yu7s47WtQW35RUpDD/Ikm4eYNKBZQilxwhJc4SjCtxcYZU9znJAYzG3H21GM+H67iv7QpZJKZFbqvrUKWlnFLew5Cwmk+GFJQ3L7iMZ+/j1MJvNhF09PsX7MkRkfrkGKkpVXkkzB4AE+sVkXkIIQEhspCQs6F8NCpC+MOa7/TRBSmYv5RmB0c5gSLzDkCitoXRCKiZ0PCxBUthgDNvvYdt9acJO6mfSABR4rV24DctOIow/ZsrRppkLIYEAIYs47CwEeXuW8CFViaWvTkGK+WAUtsf8BEguMnnxzMfjIBXlPIb8xfBDVzL/m2b3vWZSfIomy3RWZ5jPCEfPgb15mqJ4MBoEUJqYoAz1jJSRZ1l23zKV4krMQ9Rb2Xf9vRgmMsTuwtMEwgAVjeV5Ji1PzVFWMFM0kk6+5UTtwSxCSCjjTlMUSmW2s3fbhHKyiAda0YLkgQo5++xtrIycFYPR4O3lgRXcaVULS9cQQYgxEG5kCgJLXAgii5dCt+KPydCwtQSvTrnRyJR4hGU6Y/492x+nex/rFKE1OBhz65k0rYm4rwc9KF0lWtxEBCmaekf/XdRJ0kc8yl2Gjf1lhp5G0UAK0WhlLp3WCuGlxj+7EDh+tL9UHXQh8IrHfyFbRk8PDnbmwulwe+4WdE2P525A53R37gZ0Tm7v0y6Y7i8zj8SDxmh77iZ0TMIf/ttHZoiZ6T+upmOB8J+2phSCin4oy+I8dCPXFpeXDOROb2r19ENR3megAXLZ7b5kSqM9UfKvLhAHjq8sLpfygF2UXF72qAtNineHPxF0eQYqxWaaXstcMBVxfQjNz92YTuhvCSE6d2M6oVKG6dmcPp70B+3ItI+2LiFMznHo4eNudmwfyL5fa/N8ngstTQ4/iUzR5MUWaF9Ssd8NaQWbYfraBb1rBMlzhz/8eVvKHhAaOZ/Y0Zj8IyBmHYB2zQ59nE7ajsMfP03heQWb7RtHETZnN6FMihJjo0fnMrMWAP7wIvjpTUW6HkemAZYTANT+mMPdNonxFi4ZDtHhRy0peUfpWz20GqH1jYnuMoDHz8bf1wkqxNikiLEc7eMfnZWWg3eRbc4/TvN9ISqmmW72BcZGa8L6P7uH8XySLml9NztOxyAa6ncEn/eZsqJFx8mFduqfBpjbx/+4p4yMCaGQ4yaDiMbf2Fp/IpUjq9DMOjyyO8wIpe9JnePhjGL8TCoA5/ZXs2M3hMIvjAsx/pRZqcRQPc6qedyJQ1a1M0IxAl4zC70Ao4o79w9sUgbwq3ZmHEIur2Y9EAqTs8nc0DuJfnV9iAnj5eqA69oM1PFQKi+EUR6cD7kIP+kCnxtm2I5vSzwRZrqC5l+vXe4fUjFpmaLNoTa1KklQd5qRLJlWhDf6Ioyie5gJrmZos7ClxzQ2HZKa7NGV72h43C/3eoD6FwmEQgWCIk7QH2HE1ihJlsslQq/eUSYQqe9SnHA+n06Py30DsgzgVnNnWh2wiJgPQCis6svhqDrY89RZGYxPKdOnXKQ0W6L9AS2bz+voGRI7irKM2acQhJyxPyNgL2jmE2qSZxtEtiqay+liOp0OtUcB6CZr+KQ8n+Thj5BhwnD/MF2lRxVo1sYNpCTHSp81HHj0NpyNkOEsCA1CCNeH5E0VZawU1Rsh41DtZoAWSeY3Ro6re9mneXVAqq8OKAzF3Wg002Wp6hHiSnVA+bcvQih/yDjvn6zQXlymNxKS7FycFvDTFpwh0dvyMKrvHFkQytTmrLKc/AaSA3wRUmmJ8eMJQoQ+n6y6CiOP5TkpkS7tB0rz4Wgx3xvw6WQos3nSj/IsfPgjR6hdAZ82UxhCLFpYOUJF7YW8ve/+DPraNHuclV8U94M11RTPgxKg0XRp3mFCb7eDweNthR7FN4/quAvxCf7t959ecoSD9LgMEz0+3t8OHsX/PpsmGRkt/65vbmuRYJD6lsmQEk39NqjOCZWt6tmpWm5lgpNokr2gFZrvs0RQ8y11EpNvOGC+p/fFKR1n44/70uxcJkNwpUw0B1shSFqA0xYMxx4ZUB/Af6Kv/XKBlrPZ1DSQmx8wmg3RdPhlUaBToPO7h/s4lyHoanpeRLMygxkD9dW6ejtCyRkAmmxx8/0S4n669LpJ0mx3T4vihHoJxjL1LOY0WgQhTJYbBTEM4Op4RMPZ6qDXT+2toLO7flpDlmGtilJZng/8pc+pomWaAkSxLvAHKMbfcbVZoaGbijY9AI1VQpNOgkI9iUwgFBc8hnJJAKLQtYAxuDluhmg0bFrHuD5CLOgAItZIEKqeMazW9W+hXFBvKhZ3w5k3wN5xNZrNkOlkNwfuU5mWRpoBQs4YTTPwxy3YoOli4y/BXi/ZJNP9fhrOWDK/ZVR/7gyN5YRJLLGrW2p+TNB+HwAQzuVDh2kbzj2ZiQmlaJsBCjWNIZX9reH4ME82Yfcfv9DS34pWWFuSowTE+sGPbZm6t+64CJH96TMcjpCqIUx+t+1X9ytbd6bLwZ/1wzuHVojC2xp+dK9d0UxWwcKhhvln+x51g5YebRDRcGhqoX1+lJjuR7YX6Sgpjnl12KSuI7RKsXqAao1sPi75bfwZnXRRfXszKYVLoJ1136oBoYAwQqVnKwbFa9vqAaq+EBNbQIeaBuRrw9ft9m72O2/Jaf+IL3bmvYQmhFJRgV7f1x+fn38edttN3o2ofr5o/X7TUiWxD1SACFjGz6W33b8GD2/wZaV/oGHGwdiMUNiS9+eTNTW9H0uMDhLs9UzH7CYuZyXDqnjc0G78OW2Yx5pTF5rGoRBeU6gLe36TJe0cWqhXVKuKpi140G22Dd7qGNHMCyFCU62BgggDJ4A6iyq8rf0BCN2Z3FxDqSGTSa0d1215c+BaikpAbPD9Lipqa0EUTWq7SqYQuBrCxBI24F7LqK6obmPQIb77bxWh4bys6qHyR+vrraazoRspqUJ0VFGXyIxKKRfT7vMJQuR0wHvfQ4rlK12MDHKRIFAlyscQTlxB6PRm694V4onTcPCD0ALH94fsZF6FEleEjmkqD65CLLl+tzWL+2kY/ROEhnDiMkL3mpiv3orq5Ae9yiCUzyM2dQwrbea5B+VOnBGmFtVJRXs9n3fctCwb032/ctfsU1hp7YxQQrSsJvKGetXqKB0Mbp6ZPmUzaZ88I+6xATGvzZa1CL3CFAohGmdtUW790cjn8c7GBvzi0G1rwzeFJN8EtcYyKYh+cZ6x+151Mlq4XYtevADmO/UmS5pfinzsjKR356mNUFG3nW3v9IPUF7kMr3tYR/qpiKvbT36rV6kOAL0zuZTDcEtbEPNpy2itkRvCzMjoSuuUEW59EUIKkbNoPn0HgVstytyKOkjRv9DhRO4fOVa/iB58E4ufHRCWpmp2iE7xuae0Rz4exjdAN7YjPPWDFouKkH8y3qvxhNPWZH3rKxa8J6unhfFqP3+s6L3bg2xsJVMB4MkltSXxKcKAQ/bW229HdfJ4c5hMryEHbGG6ISCzpONDzz7NCBvJlID6HzzNhAWQ4aZzw7nSla50pSvl0coXz0NLdNL9sbVscs7zuTovnSd5nPG0w+ZiQd9LIfUHvo1UKQgdfU/LZPG8kBsZbT9+Zdk3fQQfRIIbIvzcCJLXgroKp/zbMOcU6r7pfoXyh1BKoVV1QNFNsYGH8UaOIXOqxSn5kDglyzLpOKQ/tBpGRKmJ/xNyzdbnZdmZM0IizDVqUELeQooyXlzLw0AlXNYcSR1BLScmeGvqksnkrLRORbAUCeFM1X3xJFnRLytp1lzez0rCTWAo+9bcdlWshUXpswMhyvJ8snSQ941c1ppiLSBC4bUIx5oBIlW0dXVADnVUcIDHlXqp8l6y/EVvv0E4JN9pc7mBQyrdNAUsAKE09XoeptYV2Uo0FaIvQlBRbFAfXEYIee0BWgq1807r/XjcygqEEHPvbWs4lAY0mUha1LDEYcXzIPEPSkiG2cFCS3Epl9CdCJd17WJDMecs6YupWo8BAIWagC0LM8J5dUCZq+wNUIrQ7ORUz4vpQGB9R1l7zTQMzKSqAzJ56EQAQKbOczAyz/1toIqq6oC6tCP77ZmTZrLQpOfdcRxzNVk0UWogWBhALnkwCw8DZQseEiBBITyGud36KxnjoPqORBXibTNjTyHSACNDwLq5FJZLj30IaKbwgkLJw5aEOanJaICey9KAsZOFg2z1oB0AKKJMOG+5rFSTBf9uAucZOzYbB69cseDRemeG4qDZApVZ6K4Xh9XZpHGbauxl9kEPoXFb9bETbq2ireg7etdGgWWAr3SlK/0/0P8AwU3bC688eQIAAAAASUVORK5CYII=" alt="">
       <h3>DENTING/PAINTING</h3>
       <ul class="lu">
         <li> Accidental dent remove works</li>
         <li> Mejor/Minor dent works</li>
         <li>Full vehicle paint or paint color change</li>
       </ul>

     </div>
     </div>
      </div>
  </section>
  <section>
    
    <?php
           $name = $address = $phone  = $car_license_number = $car_engine_number = $date =$mechanic ='';
           $nameErr = $addressErr  = $phoneErr = $car_license_numberErr = $car_engine_numberErr = $dateErr=$mechanicErr='';
           
        //    form submit
          if(isset($_POST['submit'])){
            // validate name
            // echo 'lalaa';
            if(empty($_POST['FullName'])){
              $nameErr='Name is required';
            }else{
                $name = filter_input(INPUT_POST,'FullName',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                // $name='aaaaa';
            }
            // validate address
            if(empty($_POST['Address'])){
              $addressErr='address is required';
            }else{
                $address = filter_input(INPUT_POST,'Address',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            }
             // validate phone
            if(empty($_POST['PhoneNo'])){
                $phoneErr='phone is required';
              }else{
                  $phone = filter_input(INPUT_POST,'PhoneNo',FILTER_SANITIZE_NUMBER_INT);
              }
               
               // validate car_license
            if(empty($_POST['CarLicensenumber'])){
                $car_license_numberErr='CarLicensenumber is required';
              }else{
                  $car_license_number = filter_input(INPUT_POST,'CarLicensenumber',FILTER_SANITIZE_NUMBER_INT);
              }
               // validate car_engine
            if(empty($_POST['CarEngineNumber'])){
                $car_engine_numberErr='car_engine_number is required';
              }else{
                  $car_engine_number = filter_input(INPUT_POST,'CarEngineNumber',FILTER_SANITIZE_NUMBER_INT);
              }
               // validate date
            if(empty($_POST['Appointmentdate'])){
                $dateErr='date is required';
              }else{
                // $date = preg_replace("([^0-9/])", "", $_POST['date']);
                  $date = filter_input(INPUT_POST,'Appointmentdate',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
              }
               // validate mechanic
            if(empty($_POST['mechanic'])){
                $mechanicErr='mechanic is required';
              }else{
                  $mechanic = filter_input(INPUT_POST,'mechanic',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
              }

              if(empty($nameErr) && empty($phoneErr) && empty($addressErr) && empty($car_license_numberErr) && empty($car_engine_numberErr) && empty($dateErr) && empty($mechanicErr)){
                // add to data base
                $sql= "INSERT INTO appointment_user (`Full Name`, `Address`, `Phone No.`, `Car License Number`, `Car Engine Number`, `Appointment date`, `mechanic`) VALUES ('$name', '$address', '$phone', '$car_license_number', '$car_engine_number', '$date', '$mechanic')";
                if(mysqli_query($conn, $sql)){
                    //success
                    // header("Location: admin.php");
                    // echo 'lessgoo';
                  }else{
                    echo 'Error: '. mysqli_error($conn);
                  }
              }
              
          }
        //   echo $dateErr;
        //   echo $date;
          

        ?>
    <div class="t1">

    <h2>Appointment Form :</h2>
    </div>
    <?php  
       $Shama;
       $Fuad;
       $Mahdi;
        function slots($number){
            return 3-$number;
         }
        $sql='';
        $sql= 'SELECT COUNT(mechanic) AS Appointments FROM appointment_user WHERE mechanic="Shama";';
        $result = mysqli_query($conn, $sql);
        while($row = $result->fetch_assoc()) {
          $Shama=(int)$row["Appointments"];
            
        }
        $sql='';
        $sql= 'SELECT COUNT(mechanic) AS Appointments FROM appointment_user WHERE mechanic="Mahdi";';
        $result = mysqli_query($conn, $sql);
        while($row = $result->fetch_assoc()) {
            $Mahdi=(int)$row["Appointments"];
        }
        $sql='';
        $sql= 'SELECT COUNT(mechanic) AS Appointments FROM appointment_user WHERE mechanic="Aosaf";';
        $result = mysqli_query($conn, $sql);
        while($row = $result->fetch_assoc()) {
            $Aosaf=(int)$row["Appointments"];
        }
        $sql='';
        $sql= 'SELECT COUNT(mechanic) AS Appointments FROM appointment_user WHERE mechanic="Fuad";';
        $result = mysqli_query($conn, $sql);
        while($row = $result->fetch_assoc()) {
            $Fuad=(int)$row["Appointments"];
        }
        
    
    ?>
    <div class="app">
      <form class="" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <label for="Full Name">FULL NAME</label>
        <input class="in1"type="text" name="FullName" value="">
        <label for="Address">ADDRESS</label>
        <input class="in1" type="text" name="Address" value="">
        <label for="Phone No.">Phone No.</label>
        <input class="in1" type="text" name="PhoneNo" value="">
        <label for="Car License number">Car License number</label>
        <input class="in1" type="text" name="CarLicensenumber" value="">
        <label for="Car Engine Number">Car Engine Number</label>
        <input class="in1" type="text" name="CarEngineNumber" value="">
        <label for="Appointment date">Appointment date</label>
        <input class="in1" type="date" name="Appointmentdate" value="">
        <label for="mechanic">Choose a mechanic:</label>
        <select class="in1" name="mechanic" id="mechanic" >
        <option value="" disabled selected hidden>Choose Your Mechanic</option>
                            <option value="Shama">Shama  &nbsp;(slots remaining <?php echo slots($Shama)?>)</option>
                            <option value="Fuad">Fuad  &nbsp;(slots remaining <?php echo slots($Fuad)?>)</option>
                            <option value="Mahdi">Mahdi  &nbsp;(slots remaining <?php echo slots($Mahdi)?>)</option>
                            <option value="Aosaf">Aosaf  &nbsp;(slots remaining <?php echo slots($Aosaf)?>)</option>
                           
        </select>
        <input type="submit" name="submit" value="submit">
      </form>

    </div>
  </section>

  <script type="text/javascript">
    // querySelector('.Submitbtn').addEventListener("click",function(){
    //     document.getElementById("myForm").reset();
    // })

    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
    
</script>

  </body>
</html>
