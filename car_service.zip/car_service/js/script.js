function change(element){
    // element.innerHTML='Confirm'
    
    if(element.classList.contains('normal')){
        element.classList.toggle('normal');
        // element.innerHTML='<input type="date" id="userDate" placeholder="Select Date"><button class="work-button cngDate" onclick="change(this.parentElement);">Confirm</button>';
        element.innerHTML='<form method="POST" action="/car_service/admin.php"><input type="date" id="userDate" name="Appointmentdate" placeholder="Select Date"><input type="submit" class="work-button cngDate" onclick="location.reload();"value="Confirm" name="submit"></form>';
        
    }
    else{
        element.innerHTML='<?php echo $customer["Appointmentdate"]; ?><button class="work-button cngDate" onclick="change(this.parentElement);">Change</button>'
        element.classList.toggle('normal');
    }
    
}
var update_ID;
var update_ID2;

// getting id no
function status_update(id){
    this.update_ID=id;
    // alert(update_ID);
    document.cookie="IDD="+id;

  }


  



function change2(element){
    // element.innerHTML='Confirm'
    if(element.classList.contains('normal2')){
        element.classList.toggle('normal2');
        element.innerHTML='<form method="POST" action="/car_service/admin.php"><select class="in1" name="mechanic" id="mechanic" ><option value="" disabled selected hidden>Choose Your Mechanic</option><option value="Shama">Shama</option><option value="Fuad">Fuad</option><option value="Mahdi">Mahdi</option><option value="Aosaf">Aosaf</option></select> <input type="submit" name="submit" value="submit"></form>';
        
    }
    else{
        element.classList.toggle('normal2');
        element.innerHTML='<?php echo $customer["mechanic"]; ?><button class="work-button cngMech" onclick="change2(this.parentElement);">Change</button>'
        
    }
    
}

function status_update2(id){
    this.update_ID2=id;
    // alert(update_ID);
    document.cookie="IDD2="+id;

  }



